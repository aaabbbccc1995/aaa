import React from 'react';
import { Redirect, Route, withRouter } from 'react-router-dom';
import {connect} from 'react-redux';

class AuthorizedRoute extends React.Component {
    render () {
        const { component: Component, logged, auth, ...rest } = this.props
        return (
            <Route {...rest} render={props => {
                console.log(logged, rest.auths)
                if (!logged) {
                    return <Redirect to="/login" />
                } else {
                    if (rest.auths) {
                        if (auth.includes(rest.auths)) {
                            return <Component {...props} />
                        } else {
                            return <Redirect to="/404" />
                        }
                    } else {
                        return <Component {...props} />
                    }
                }
            }} />
        )
    }
}

const stateProps = ({GlobalUserInfoReducer}) => ({
    logged: GlobalUserInfoReducer.logged,
    auth: GlobalUserInfoReducer.auth
}) 

export default withRouter(connect(stateProps)(AuthorizedRoute))