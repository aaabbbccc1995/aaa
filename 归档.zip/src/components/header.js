import React, { useState, useEffect } from 'react';

let nowTime = 1592179200000;
function getTimes() {
    let time = new Date().getTime();
    let t = (nowTime - time) / 1000;
    let d = Math.floor(t / (24 * 3600));
    let h = Math.floor((t - 24 * 3600 * d) / 3600);
    let m = Math.floor((t - 24 * 3600 * d - h * 3600) / 60);
    let s = Math.floor((t - 24 * 3600 * d - h * 3600 - m * 60));
    return {
        d, h, m, s
    }
}

function GoHome() {
    const [time, setTime] = useState(getTimes);
    let timer = () => {
        setInterval(() => {
            setTime(getTimes);
        }, 1000)
    }
    useEffect(() => {
        timer();
    })
    return (
        <>
            <div style={{paddingLeft: 16, paddingTop: 16}}>
                G o H o m e - {time.d}天 {time.h}时 {time.m}分 {time.s}秒
            </div>
        </>
    )
}

function H() {
    return (
        <>
            <div>
                <GoHome></GoHome>
            </div>
        </>
    )
}

export default H;