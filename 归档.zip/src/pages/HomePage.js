import React from 'react'
import { Switch, Route, NavLink } from 'react-router-dom'
import UserNav from '../layouts/UserNav';

// Sub Layouts
import BrowseUsersPage from '../pages/BrowseUsersPage'
import AddUserPage from '../pages/AddUserPage'

const HomePage = ({match}) => (
  <div>
        <UserNav></UserNav>
    <br/>

    <div className="primary-content" data-match={match.path}>
        <Switch>
            <Route path={match.path} exact component={BrowseUsersPage} />
            <Route path={`${match.path}/add`} component={AddUserPage} />
        </Switch>
    </div>
  </div>
)

export default HomePage