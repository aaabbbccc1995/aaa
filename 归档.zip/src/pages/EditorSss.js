import React from 'react'
import { Switch, Route, NavLink } from 'react-router-dom'
import UserNav from '../layouts/UserNav';

// Sub Layouts
import BrowseUsersPage from '../pages/BrowseUsersPage'
import AddUserPage from '../pages/AddUserPage'

const EditorSss = ({match}) => (
  <div>
      EditorSss
  </div>
)

export default EditorSss