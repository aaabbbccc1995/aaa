
import React from 'react'

const AddUsersPage = () => (
  <div>
    斗地主详情页面
  </div>
)

export default AddUsersPage