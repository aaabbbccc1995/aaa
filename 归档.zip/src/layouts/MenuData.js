import store from '../store';
// export const MenuData = [
//     {
//         type: 'menu',
//         icon: 'desktop',
//         text: '首页',
//         key: '/app/index',
//         subMenu: [
//             {
//                 key: '2',
//                 text: 'HomePage',
//                 url: '/app/index/home'
//             },{
//                 key: '3',
//                 text: 'ABC',
//                 url: '/app/index/abc'
//             }
//         ]
//     }, 
//     {
//         type: 'menu1',
//         icon: 'desktop',
//         text: '编辑',
//         key: '/app/editor',
//         subMenu: [
//             {
//                 key: '5',
//                 text: '超级编辑',
//                 url: '/app/editor/super'
//             },{
//                 key: '',
//                 text: '一般编辑',
//                 url: '/app/editor/fuck'
//             }
//         ]
//     }
// ]

export let data = [
    {
        auth: 'aa',
        name: '用户管理',
        url: '/app/index',
        icon: 'desktop',
        children: [
            {
                auth: 'aa-a1',
                name: '玩家列表',
                url: '/app/index/home'
            },
            {
                auth: 'aa-a2',
                name: '牌局记录',
                url: '/app/index/abc',
            }
        ]
    }, {
        auth: 'bb',
        name: '编辑',
        icon: 'desktop',
        url: '/app/editor',
        children: [
            {
                auth: 'bb-b1',
                name: '编辑栏目一',
                url: '/app/editor/abc',
            },
            {
                auth: 'bb-b2',
                name: '编辑栏目二',
                url: '/app/editor/sss',
            }
        ]
    }
    // , {
    //     auth: 'cc',
    //     name: '数据统计',
    //     children: [
    //         {
    //             auth: 'cc-c1',
    //             name: '房间在线人数'
    //         },
    //         {
    //             auth: 'cc-c2',
    //             name: '机器人统计数据'
    //         }
    //     ]
    // }, {
    //     auth: 'dd',
    //     name: '充值管理',
    //     children: [
    //         {
    //             auth: 'dd-d1',
    //             name: '充值订单'
    //         },
    //         {
    //             auth: 'dd-d2',
    //             name: '支付设置'
    //         }
    //     ]
    // }, {
    //     auth: 'ee',
    //     name: '第三方管理',
    //     children: [
    //         {
    //             auth: 'dd-d1',
    //             name: '第三方订单报表'
    //         },
    //         {
    //             auth: 'dd-d2',
    //             name: '渠道设置'
    //         }
    //     ]
    // }
]

export function gt (routerArr) {
    // console.log(routerArr, '--------------------')
    const arr = [];
    let obj = {};
    routerArr.forEach(router => {
        const tmp = { ...router };
        // console.log(tmp, '???????????????????')
        if (store.getState().GlobalUserInfoReducer.auth.includes(tmp.auth)) {  //只筛选auth 在autharr数组中的对象
            if (tmp.children) {
                tmp.children = gt(tmp.children);
                // console.log(tmp, '??????????????????????????????????????')
            }
            obj = {
                ...tmp
            }
            arr.push(obj);
        }
    })
    return arr;
}

