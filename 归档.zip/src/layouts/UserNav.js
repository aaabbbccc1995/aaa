import React from 'react'
import { NavLink, withRouter } from 'react-router-dom'
import './a.css'

const UserNav = ({ match }) => (
  <nav className="context-nav">
    <NavLink to={`${match.path}`} exact activeClassName="active">牌局详情</NavLink>
    <NavLink to={`${match.path}/add`} activeClassName="active">斗地主详情</NavLink>
  </nav>
)

export default withRouter(UserNav)