import React from 'react'
import { Switch, Route, NavLink } from 'react-router-dom'
import HomePage from '../pages/HomePage';
import Welcome from '../routes/HomePage/Home';

// Sub Layouts
import BrowseUsersPage from '../pages/BrowseUsersPage'
import AddUserPage from '../pages/AddUserPage'
import UserProfilePage from '../pages/UserProfilePage'

const UserSubLayout = ({ match }) => (
  <div className="user-sub-layout">
    <div className="primary-content" data-match={match.path}>
        <Switch>
            <Route path={match.path} exact component={Welcome} />
            <Route path={`${match.path}/home`} component={HomePage} />
        </Switch>
    </div>
  </div>
)

export default UserSubLayout