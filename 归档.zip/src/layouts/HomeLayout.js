import React, {useState, useEffect} from "react";
import { Layout, Menu, Breadcrumb, Icon } from 'antd';
import {Route, Link, withRouter, Switch, Redirect} from 'react-router-dom';
import {data, gt} from './MenuData';
import Index from '../routes/Index/index'
import AuthorizedRoute from '../components/privateRoute'
import HomePage from '../routes/HomePage/index';
import Home from '../routes/HomePage/Home';
import Super from '../routes/Editor/super'
import Fuck from '../routes/Editor/fuck'
import IndexLayout from './IndexLayout';
import EditorLayout from './EditorLayout';
const { Content, Footer, Sider } = Layout;
const { SubMenu } = Menu;


function HomeLayout(props) {
    const [collapsed, setCollapsed] = useState(false);
    const [MenuData, useMenuData] = useState(gt(data));
    let onCollapse = collapsed => {
        setCollapsed(collapsed);
    };
    useEffect(() => {
      const a = data.filter(item => {
        return item.url == props.location.pathname.split('/').slice(0, 3).join('/')
      });
      console.log(a[0] ? a[0]['name']: '')

      if (a[0]) {
        let b = a[0].children.filter(item => {
          console.log(item.url, props.location.pathname.split('/').slice(0, 4).join('/'))
          return item.url == props.location.pathname.split('/').slice(0, 4).join('/')
        })
        console.log(a[0] ? a[0]['name']: '', '---', b[0] ? b[0]['name'] : '')
      }
      // console.log(props.history.location.pathname.split('/').slice(0, 3).join('/'))
      // console.log(data.filter(item => item.url == props.history.location.pathname.split('/').slice(0, 3).join('/')).name)
    }, [props.location])
    return (
        <Layout style={{ minHeight: '100vh' }}>
          <Sider collapsible collapsed={collapsed} onCollapse={onCollapse}>
            <div className="logo" />
            <Menu 
                theme="dark" 
                defaultSelectedKeys={[props.history.location.pathname.split('/').slice(0, 4).join('/')]} 
                mode="inline" 
                selectedKeys={[props.history.location.pathname.split('/').slice(0, 4).join('/')]}
                defaultOpenKeys={[props.history.location.pathname.split('/').slice(0, 3).join('/')]}
            >
            <Menu.Item key="/app" icon='desktop'>
                <Link to='/app'>Welcome</Link>
            </Menu.Item>
              {MenuData.map(item => {
                 return (
                  <SubMenu
                    key={item.url}
                    title={
                      <span>
                        <Icon type={item.icon} />
                        <span>{item.name}</span>
                      </span>
                    }
                  >
                    {
                      item.children.map(cItem => 
                        <Menu.Item 
                          key={cItem.url}>
                            <Link to={cItem.url}>{cItem.name}</Link>
                        </Menu.Item>)
                    }
                  </SubMenu>
                )
              })}
            </Menu>
          </Sider>
          <Layout>
            <Content style={{ margin: '0 16px' }}>
              <Breadcrumb style={{ margin: '16px 0' }}>
                <Breadcrumb.Item>User</Breadcrumb.Item>
                <Breadcrumb.Item>Bill</Breadcrumb.Item>
              </Breadcrumb>
              <div style={{ padding: 24, background: '#fff', minHeight: 360 }}>
                <Switch>
                    <Route path='/app' exact component={Home} />
                    <Route path='/app/index' component={IndexLayout} />
                    <Route path='/app/editor' component={EditorLayout} />
                    {/* <Route path='/app/index/abc' component={Index} />
                    <Route path='/app/editor/super' component={Super} />
                    <Route path='/app/editor/fuck' component={Fuck} /> */}
                    <Redirect to='/app' />
                </Switch>
              </div>
            </Content>
            <Footer style={{ textAlign: 'center' }}>Ant Design ©2018 Created by Ant UED</Footer>
          </Layout>
        </Layout>
      );
}

export default withRouter(HomeLayout);