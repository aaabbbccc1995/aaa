import React from 'react'
import { Switch, Route, Redirect } from 'react-router-dom'
import EditorAbc from '../pages/EditorAbc';
import EditorSss from '../pages/EditorSss';
import Welcome from '../routes/HomePage/Home';
import AuthorizedRoute from '../components/privateRoute'

// Sub Layouts
import BrowseUsersPage from '../pages/BrowseUsersPage'
import AddUserPage from '../pages/AddUserPage'
import UserProfilePage from '../pages/UserProfilePage'

const EditorLayout = ({ match }) => (
  <div className="user-sub-layout">
    <aside>
        编辑编辑
    </aside>
    <div className="primary-content" data-match={match.path}>
        <Switch>
            <Route path={match.path} exact component={Welcome} />
            <AuthorizedRoute path={`${match.path}/abc`} component={EditorAbc} auths='bb-b1' />
            <Route path={`${match.path}/sss`} component={EditorSss} />
            <Redirect to={match.path} />
        </Switch>
    </div>
  </div>
)

export default EditorLayout