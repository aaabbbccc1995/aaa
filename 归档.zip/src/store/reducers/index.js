import { combineReducers } from 'redux';
import GlobalUserInfoReducer from './global_userinfo_reducer';

const rootReducer = combineReducers({
    GlobalUserInfoReducer
})

export default rootReducer