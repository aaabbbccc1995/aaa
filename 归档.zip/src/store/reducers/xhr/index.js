import store from '../../index';

export const login = () => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        store.dispatch({
          type: 'SET_LOGIN_STATE',
          value: [true, ['aa', 'aa-a1', 'bb', 'bb-b1', 'bb-b2']]
        })
        resolve()
      }, 3000)
    })
  }