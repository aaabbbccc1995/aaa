// 全局显示文字
const GlobalUserInfoReducer = (state = {
    systemTitle: 'Antd Demo',
    userName: '',
    account: '',
    avatar: '',
    email: '',
    logged: localStorage.getItem('logged') ? JSON.parse(localStorage.getItem('logged')) : false,
    auth: localStorage.getItem('auth') ? JSON.parse(localStorage.getItem('auth')) : []
}, action) => {
    switch(action.type) {
        case 'SET_LOGIN_STATE':
            let newState = JSON.parse(JSON.stringify(state))
            localStorage.setItem('logged', JSON.stringify(action.value[0]))
            localStorage.setItem('auth', JSON.stringify(action.value[1]))
            newState.logged = action.value[0];
            newState.auth = action.value[1]
            return newState;
        default:
            return state;
    }
}

export default GlobalUserInfoReducer;