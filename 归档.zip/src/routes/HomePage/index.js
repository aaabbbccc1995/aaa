import React from 'react'

const AppHomePage = ({ history }) => (
  <div>
    App Home Page
  </div>
)

export default AppHomePage