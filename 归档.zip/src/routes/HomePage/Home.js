import React from 'react'

const Home = ({ history }) => (
  <div>
    Welcome123
  </div>
)

export default Home