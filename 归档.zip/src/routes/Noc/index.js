import React from "react";

function Noc(props) {
    return (
        <>
            <div>404</div>
        </>
    )
}

export default Noc;