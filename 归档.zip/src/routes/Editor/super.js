import React from 'react'

const Super = ({ history }) => (
  <div>
    Super
  </div>
)

export default Super