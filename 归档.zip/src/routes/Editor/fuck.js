import React from 'react'

const Fuck = ({ history }) => (
  <div>
    Fuck
  </div>
)

export default Fuck