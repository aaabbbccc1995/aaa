export const MenuData = [
    {
        type: 'menu',
        icon: 'desktop',
        text: 'BContent',
        subMenu: [
            {
                key: '2',
                text: 'BB',
                url: '/index/bb'
            },{
                key: '3',
                text: 'CC',
                url: '/index/cc'
            }
        ]
    }
]