import React, {useState, useEffect} from "react";
import { Layout, Menu, Breadcrumb, Icon } from 'antd';
import {Route, Link, withRouter, Switch, Redirect} from 'react-router-dom';
import H from '../../components/header';
import AuthorizedRoute from '../../components/privateRoute'
import {MenuData} from './MenuData';
const { Content, Footer, Sider } = Layout;
const { SubMenu } = Menu;

function Aa() {
  return <span href='#'>百度<input /></span>
}
function Asdf() {
  return <span>Google span</span>
}
function Bb() {
  return (
    <span href='#'>谷歌<input />
      <Route path='/index/bb/ak' component={Asdf} />
    </span>
  )
}
function Cc() {
  return <span href='#'>360<input /></span>
}

function Index(props) {
    const [collapsed, setCollapsed] = useState(false);
    let onCollapse = collapsed => {
        setCollapsed(collapsed);
    };
    useEffect(() => {
      console.log(props.location);
    }, [props.location])
    return (
        <div>
          Index
        </div>
      );
}

export default withRouter(Index);