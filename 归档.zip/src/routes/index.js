import React from 'react'
import { BrowserRouter as Router, Route, Switch, Redirect, HashRouter} from 'react-router-dom';
import Login from './login/index'
import Index from './Index/index'
import HomeLayout from '../layouts/HomeLayout';
import Noc from './Noc/index'
import AuthorizedRoute from '../components/privateRoute'

function AppRouter() {
    return (
        <HashRouter>
            <Switch>
                <Route path='/login' component={Login} />
                <AuthorizedRoute path='/app' component={HomeLayout} />
                <Redirect to="/login" />
            </Switch>
        </HashRouter>
    )
}

export default AppRouter;

// var str = `他将是妳的新郎从今以后他就是妳一生的伴,
// 他的一切都将和妳紧密相关福和祸都要同当,
// 她将是你的新娘她是别人用心托付在你手上,
// 你要用你一生加倍照顾对待苦或喜都要同享,
// 一定是特别的缘份才可以一路走来变成了一家人,
// 他多爱妳几分妳多还他几分找幸福的可能,
// 从此不再是一个人,
// 要处处时时想着念的都是我们,
// 你付出了几分爱就圆满了几分,
// 一定是特别的缘份才可以一路走来变成了一家人,
// 他多爱妳几分妳多还他几分找幸福的可能,
// 从此不再是一个人,
// 要处处时时想着念的都是我们,
// 你付出了几分爱就圆满了几分,
// 他将是妳的新郎从今以后他就是妳一生的伴,
// 他的一切都将和妳紧密相关福和祸都要同当,
// 她将是你的新娘她是别人用心托付在你手上,
// 你要用你一生加倍照顾对待苦或喜都要同享,
// 一定是特别的缘份才可以一路走来变成了一家人,
// 他多爱妳几分妳多还他几分找幸福的可能,
// 从此不再是一个人,
// 要处处时时想着念的都是我们,
// 你付出了几分爱就圆满了几分,
// 一定是特别的缘份才可以一路走来变成了一家人,
// 他多爱妳几分妳多还他几分找幸福的可能,
// 从此不再是一个人,
// 要处处时时想着念的都是我们,
// 你付出了几分爱就圆满了几分,
// 你付出了几分爱就圆满了几分`

// var arr = str.split(',')
// let isndfsjdf = 0;
// setInterval(function() {
//     document.getElementById('veditor1_Iframe').contentWindow.document.body.innerText = arr[isndfsjdf++]
//     document.getElementById('btnPostMsg').click()
// }, 1200)