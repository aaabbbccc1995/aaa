import React, {useState} from "react";
import {connect} from 'react-redux';
import 'antd/dist/antd.css';
import './index.css';
import {Card, Input, Icon, Button, Spin} from 'antd';
import { login } from '../../store/reducers/xhr';
import { withRouter } from "react-router-dom";

function Login(props) {
    const [userName , setUserName] = useState('');
    const [password , setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const checkLogin = ()=>{
        console.log(userName, password)
        setIsLoading(true)
        sessionStorage.setItem('isLogin', '1')
        setTimeout(()=>{
            setIsLoading(false);
            props.history.push('/');
        },1000)
    }
    return (
        <>
            <div className="login-div">
                <Spin tip="登录中..." spinning={isLoading}>
                    <Card title={props.userInfo.systemTitle} bordered={true} style={{ width: 400 }} >
                        <Input
                            id="userName"
                            size="large"
                            placeholder="Enter your userName"
                            prefix={<Icon type="user" style={{color:'rgba(0,0,0,.25)'}} />}
                            onChange={(e)=>{setUserName(e.target.value)}}
                        /> 
                        <br/><br/>
                        <Input.Password
                            id="password"
                            size="large"
                            placeholder="Enter your password"
                            prefix={<Icon type="key" style={{color:'rgba(0,0,0,.25)'}} />}
                            onChange={(e)=>{setPassword(e.target.value)}}
                        />     
                        <br/><br/>
                        <Button type="primary" size="large" block onClick={() => {
                                setIsLoading(true)
                                login().then(() => {
                                    props.history.push('/app')
                                    setIsLoading(false)
                                })
                            }} > Login in </Button>
                    </Card>
                </Spin>
            </div>
        </>
    )
}

const mapStateToProps = (state, OwnProps) => {
    return {
        userInfo: state.GlobalUserInfoReducer
    }
}
const dispatchToProps = (dispatch) =>{
    return {
        inputChange(e){
            dispatch({
                type: 'SET_LOGIN_STATE',
                value: [true, ['index', 'menu-aa', 'menu-cc']]
            })
        }
    }
}
export default withRouter(connect(mapStateToProps, dispatchToProps)(Login));

